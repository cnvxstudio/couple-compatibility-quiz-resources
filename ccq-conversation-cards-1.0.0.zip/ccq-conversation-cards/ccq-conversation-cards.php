<?php
/**
 * Plugin Name: Couple Conversation Cards
 * Plugin URI: https://couplecompatibilityquiz.com/
 * Description: Add a private, accessible conversation prompt picker using the [ccq_conversation_cards] shortcode. Works without an account or external service.
 * Version: 1.0.0
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: Ethan Lee
 * Author URI: https://couplecompatibilityquiz.com/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ccq-conversation-cards
 *
 * @package CCQ_Conversation_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The original, locally bundled prompts; no user answers are requested. */
function ccq_cards_prompts() {
	return array(
		'communication' => array(
			'label' => __( 'Communication', 'ccq-conversation-cards' ),
			'questions' => array(
				__( 'What is one thing I understood well about you this week?', 'ccq-conversation-cards' ),
				__( 'When a conversation gets tense, what would help us pause and return to it?', 'ccq-conversation-cards' ),
				__( 'Is there a small request you have made that we could make more specific?', 'ccq-conversation-cards' ),
			),
		),
		'trust' => array(
			'label' => __( 'Trust and respect', 'ccq-conversation-cards' ),
			'questions' => array(
				__( 'What does keeping a small promise look like to each of us?', 'ccq-conversation-cards' ),
				__( 'Is there a boundary around privacy, friendships or alone time that we should clarify?', 'ccq-conversation-cards' ),
				__( 'What helps you feel heard when you say no?', 'ccq-conversation-cards' ),
			),
		),
		'everyday' => array(
			'label' => __( 'Everyday life', 'ccq-conversation-cards' ),
			'questions' => array(
				__( 'Which everyday responsibility feels heavier than it looks from the outside?', 'ccq-conversation-cards' ),
				__( 'What is one adjustment that would make next week easier for each of us?', 'ccq-conversation-cards' ),
				__( 'How would you like to balance time together and time on your own?', 'ccq-conversation-cards' ),
			),
		),
		'direction' => array(
			'label' => __( 'Shared direction', 'ccq-conversation-cards' ),
			'questions' => array(
				__( 'What personal goal would you like me to understand better?', 'ccq-conversation-cards' ),
				__( 'Is there an upcoming choice where we need to hear both priorities before deciding?', 'ccq-conversation-cards' ),
				__( 'What would a realistic, enjoyable month together include?', 'ccq-conversation-cards' ),
			),
		),
		'connection' => array(
			'label' => __( 'Emotional connection', 'ccq-conversation-cards' ),
			'questions' => array(
				__( 'What small gesture has helped you feel cared for recently?', 'ccq-conversation-cards' ),
				__( 'Is there something you used to enjoy together that you would like to revisit?', 'ccq-conversation-cards' ),
				__( 'What is one thing you are curious to learn about each other now?', 'ccq-conversation-cards' ),
			),
		),
	);
}

/** Register the local assets and load them on posts containing the shortcode. */
function ccq_cards_assets() {
	wp_register_style( 'ccq-conversation-cards', plugins_url( 'assets/cards.css', __FILE__ ), array(), '1.0.0' );
	wp_register_script( 'ccq-conversation-cards', plugins_url( 'assets/cards.js', __FILE__ ), array(), '1.0.0', true );
	global $wp_query;
	$needed = false;
	if ( isset( $wp_query->posts ) && is_array( $wp_query->posts ) ) {
		foreach ( $wp_query->posts as $candidate ) {
			if ( $candidate instanceof WP_Post && has_shortcode( $candidate->post_content, 'ccq_conversation_cards' ) ) {
				$needed = true;
				break;
			}
		}
	}
	/** Allow themes that place the shortcode outside post content to opt in. */
	if ( apply_filters( 'ccq_cards_enqueue_assets', $needed ) ) {
		wp_enqueue_style( 'ccq-conversation-cards' );
		wp_enqueue_script( 'ccq-conversation-cards' );
	}
}
add_action( 'wp_enqueue_scripts', 'ccq_cards_assets' );

/** Render an isolated picker. The optional topic is restricted to bundled keys. */
function ccq_cards_shortcode( $atts ) {
	$atts   = shortcode_atts( array( 'topic' => 'all' ), $atts, 'ccq_conversation_cards' );
	$groups = ccq_cards_prompts();
	$topic  = sanitize_key( $atts['topic'] );
	if ( 'all' !== $topic && ! isset( $groups[ $topic ] ) ) {
		$topic = 'all';
	}
	$id = wp_unique_id( 'ccq-cards-' );
	$first_group = 'all' === $topic ? 'communication' : $topic;
	wp_enqueue_script( 'ccq-conversation-cards' );
	ob_start();
	?>
	<section class="ccq-cards" data-ccq-cards data-initial-topic="<?php echo esc_attr( $topic ); ?>" aria-labelledby="<?php echo esc_attr( $id ); ?>-title">
		<h2 id="<?php echo esc_attr( $id ); ?>-title"><?php esc_html_e( 'A little time to talk', 'ccq-conversation-cards' ); ?></h2>
		<p><?php esc_html_e( 'Choose a question, take turns, and listen. You can skip any topic.', 'ccq-conversation-cards' ); ?></p>
		<div class="ccq-cards-controls" data-ccq-controls hidden>
			<label for="<?php echo esc_attr( $id ); ?>-topic"><?php esc_html_e( 'Topic', 'ccq-conversation-cards' ); ?></label>
			<select id="<?php echo esc_attr( $id ); ?>-topic" data-ccq-topic>
				<option value="all" <?php selected( $topic, 'all' ); ?>><?php esc_html_e( 'All topics', 'ccq-conversation-cards' ); ?></option>
				<?php foreach ( $groups as $key => $group ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $topic, $key ); ?>><?php echo esc_html( $group['label'] ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<p class="ccq-cards-question" data-ccq-question aria-live="polite" aria-atomic="true"><?php echo esc_html( $groups[ $first_group ]['questions'][0] ); ?></p>
		<div class="ccq-cards-actions" data-ccq-controls hidden>
			<button type="button" data-ccq-next><?php esc_html_e( 'Another question', 'ccq-conversation-cards' ); ?></button>
			<button type="button" data-ccq-copy><?php esc_html_e( 'Copy question', 'ccq-conversation-cards' ); ?></button>
		</div>
		<p class="ccq-cards-status" data-ccq-status data-copy-success="<?php esc_attr_e( 'Question copied.', 'ccq-conversation-cards' ); ?>" data-copy-failure="<?php esc_attr_e( 'Copy is unavailable here. Select the question text and copy it manually.', 'ccq-conversation-cards' ); ?>" role="status" aria-live="polite"></p>
		<details class="ccq-cards-bank">
			<summary><?php esc_html_e( 'Browse all 15 questions', 'ccq-conversation-cards' ); ?></summary>
			<?php foreach ( $groups as $key => $group ) : ?>
				<h3><?php echo esc_html( $group['label'] ); ?></h3>
				<ul>
					<?php foreach ( $group['questions'] as $question ) : ?>
						<li data-ccq-bank-topic="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $question ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endforeach; ?>
		</details>
		<p class="ccq-cards-note"><?php esc_html_e( 'A conversation activity, not a relationship assessment. No answers are collected or stored.', 'ccq-conversation-cards' ); ?></p>
	</section>
	<?php
	return ob_get_clean();
}
add_shortcode( 'ccq_conversation_cards', 'ccq_cards_shortcode' );
