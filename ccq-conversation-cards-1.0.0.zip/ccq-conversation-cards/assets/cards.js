/* Couple Conversation Cards — GPL-2.0-or-later. No requests or browser storage. */
(function () {
  'use strict';

  function initialise(root) {
    if (root.dataset.ccqReady) return;
    root.dataset.ccqReady = 'true';
    var picker = root.querySelector('[data-ccq-topic]');
    var question = root.querySelector('[data-ccq-question]');
    var status = root.querySelector('[data-ccq-status]');
    var bank = Array.from(root.querySelectorAll('[data-ccq-bank-topic]'));
    var copy = root.querySelector('[data-ccq-copy]');
    var copying = false;
    root.querySelectorAll('[data-ccq-controls]').forEach(function (control) {
      control.hidden = false;
    });

    function next() {
      var choices = bank.filter(function (item) {
        return picker.value === 'all' || item.dataset.ccqBankTopic === picker.value;
      }).map(function (item) { return item.textContent.trim(); });
      var different = choices.filter(function (text) { return text !== question.textContent; });
      if (different.length) choices = different;
      if (choices.length) question.textContent = choices[Math.floor(Math.random() * choices.length)];
      status.textContent = '';
    }

    picker.addEventListener('change', next);
    root.querySelector('[data-ccq-next]').addEventListener('click', next);
    copy.addEventListener('click', async function () {
      if (copying) return;
      copying = true;
      copy.disabled = true;
      try {
        if (!navigator.clipboard || !window.isSecureContext) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(question.textContent);
        status.textContent = status.dataset.copySuccess;
      } catch (error) {
        status.textContent = status.dataset.copyFailure;
      } finally {
        copying = false;
        copy.disabled = false;
      }
    });
  }

  function start() {
    document.querySelectorAll('[data-ccq-cards]').forEach(initialise);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
}());
