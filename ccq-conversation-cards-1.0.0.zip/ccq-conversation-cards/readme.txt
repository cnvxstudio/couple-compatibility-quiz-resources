=== Couple Conversation Cards ===
Tags: conversation, shortcode, relationships, accessibility
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple, private conversation prompt picker with 15 original questions, five topics, random selection and one-click copying.

== Description ==

Give readers a small activity they can use together. Add [ccq_conversation_cards] to a Shortcode block to show fifteen open-ended questions about communication, trust, everyday life, shared direction and connection.

Readers can choose a topic, ask for another question, copy the current question or browse the full list. Consecutive random selections avoid repeating the same question. Multiple pickers on one page work independently. The complete question list remains available without JavaScript.

There are no accounts, subscriptions, API keys or external requests. The plugin does not accept answers, score relationships, use cookies, read browser storage or send analytics. It adds no promotional links to your public pages. All scripts, styles and questions are bundled locally.

The questions were prepared for [Couple Compatibility Quiz](https://couplecompatibilityquiz.com/), which also offers free relationship quizzes and a larger conversation question collection. This plugin works independently of that website.

This is a conversation activity, not counselling or a diagnostic test. Readers may skip any question.

== Installation ==

1. Upload the ZIP using Plugins > Add New > Upload Plugin, then activate it.
2. Add a Shortcode block to a page or post.
3. Enter [ccq_conversation_cards] and publish the page.
4. Optionally choose the initial topic: [ccq_conversation_cards topic="everyday"].

Available topic values: all, communication, trust, everyday, direction, connection. An unrecognised value falls back to all topics. Visitors can still switch topics.

== Frequently Asked Questions ==

= Are answers sent anywhere? =

No. There is no answer field. Topic and question changes stay in the page's memory and reset on reload. Copying writes only the selected question to the visitor's clipboard, with browser permission.

= Does the copy button require HTTPS? =

Yes, the browser Clipboard API requires a secure context and may also be blocked by browser permissions. If unavailable, an accessible message explains how to copy manually.

= Can I use several pickers on one page? =

Yes. Each instance has its own controls and unique labels.

= Can a theme render this shortcode outside post content? =

Yes. Add the WordPress filter add_filter( 'ccq_cards_enqueue_assets', '__return_true' ); to your theme or integration so the local stylesheet and script are enqueued before the page header. Ordinary Shortcode blocks in posts or pages load the assets automatically.

= Is any build step or third-party service required? =

No. The readable PHP, CSS and JavaScript files in the ZIP are the complete source. There are no dependencies or compilation steps.

== Changelog ==

= 1.0.0 =
* First release: fifteen prompts, topic picker, non-repeating random choice, clipboard feedback and a no-JavaScript question list.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
